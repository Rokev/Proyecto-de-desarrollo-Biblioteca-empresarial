package com.app.Biblioteca;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class BibliotecaApplicationTests {

	@Test
	void contextLoads() {
	}

}
